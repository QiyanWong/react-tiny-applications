This project consists two components:Vote and VotingPanel

VotingPanel actually contains a big table of which every row is a Vote component
Vote component includes vote logic and website information including hyper link and descriptions.

When user click "Add Your Favorite Website" button, a form will appear and allows user to type in website information, once user finishes  it and clicks "submit" button, a new record will be added onto table and the form will disappear.